
//valor CDI já convertido da %
export const CDI = 0.1325

//valor que o banco paga sobre o CDI - já convertido do %
export const TB = 1.05